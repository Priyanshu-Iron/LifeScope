const phoneNumber = document.querySelector('.phone-number');
phoneNumber.textContent='+384767567889';